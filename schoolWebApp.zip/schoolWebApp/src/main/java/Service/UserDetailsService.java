package Service;

public interface UserDetailsService {

}
