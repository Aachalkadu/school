package Service;

public class UsernameNotFoundException extends Throwable {
    public UsernameNotFoundException(String s) {
    }
}
