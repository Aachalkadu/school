package Service;

public class BCryptPasswordEncoder {
    public String encode(String password) {
        return "";
    }
}
