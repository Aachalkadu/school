package Enum;

public enum Role {
	STUDENT,
	ADMIN

}
