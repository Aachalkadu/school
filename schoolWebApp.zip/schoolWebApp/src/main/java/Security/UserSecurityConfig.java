package Security;

//package Security;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@EnableWebSecurity
//public class UserSecurityConfig extends WebSecurityConfigurerAdapter {
//
//  @Autowired
//  private UserDetailsService userDetailsService;
//
//  @Autowired
//  private JwtRequestFilter jwtRequestFilter;
//
//  @Autowired
//  public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//      auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
//  }
//
//  @Bean
//  public PasswordEncoder passwordEncoder() {
//      return new BCryptPasswordEncoder();
//  }
//
//  @Override
//  protected void configure(HttpSecurity http) throws Exception {
//      http.csrf().disable()
//              .authorizeRequests()
//              .antMatchers("/login").permitAll()
//              .anyRequest().authenticated()
//              .and().sessionManagement()
//              .sessionCreationPolicy(SessionCreationPolicy.STATELESS);
//
//      http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);
//  }
//}