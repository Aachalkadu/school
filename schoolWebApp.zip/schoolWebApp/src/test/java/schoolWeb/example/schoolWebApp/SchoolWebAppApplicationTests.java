package schoolWeb.example.schoolWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
